package services;

import java.sql.SQLException;
import java.util.List;
import javax.sql.DataSource;
import dataaccess.UserDB;
import models.User;

public class UserService {

	private UserDB userDB;

	public UserService(DataSource dataSource) {
		userDB = new UserDB(dataSource);
	}

	public List<User> getUsers() throws Exception {
		return userDB.getUser();
	}

	public User getUser(String email) throws Exception {
		return userDB.getUser(email);
	}

	public void addUser(User user) throws SQLException {
		userDB.addUser(user);
	}
}
