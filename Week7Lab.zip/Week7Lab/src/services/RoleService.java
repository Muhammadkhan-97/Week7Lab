package services;

import java.util.List;
import javax.sql.DataSource;
import dataaccess.RoleDB;
import models.Role;

public class RoleService {

	private RoleDB roleDB;

	public RoleService(DataSource dataSource) {
		roleDB = new RoleDB(dataSource);
	}

	public List<Role> getRoles() throws Exception {
		return roleDB.getRoles();
	}

}
