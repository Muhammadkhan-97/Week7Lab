package dataaccess;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import models.Role;

public class RoleDB {

	private DataSource dataSource;

	public RoleDB(DataSource dataSource) {
		this.dataSource = dataSource;
	}

	public List<Role> getRoles() throws Exception {
		
		List<Role> roles = new ArrayList<>();

		Connection myConn = null;
		Statement myStmt = null;
		ResultSet myRs = null;

		try {
			myConn = dataSource.getConnection();

			String sql = "SELECT * FROM role";
			myStmt = myConn.createStatement();

			myRs = myStmt.executeQuery(sql);

			while (myRs.next()) {
				int roleId = myRs.getInt("role_id");
				String roleName = myRs.getString("role_name");

				Role role = new Role(roleId, roleName);
				roles.add(role);
			}

			return roles;

		} finally {
			close(myConn, myStmt, myRs);
		}
	}

	private void close(Connection myConn, Statement myStmt, ResultSet myRs) {
		// TODO Auto-generated method stub
		try {
			if (myRs != null) {
				myRs.close();
			}

			if (myStmt != null) {
				myStmt.close();
			}

			if (myConn != null) {
				myConn.close();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
