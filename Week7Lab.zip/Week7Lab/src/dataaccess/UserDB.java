package dataaccess;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import models.Role;
import models.User;

public class UserDB {

	private DataSource dataSource;

	public UserDB(DataSource dataSource) {
		this.dataSource = dataSource;
	}

	public List<User> getUser() throws Exception {

		List<User> user = new ArrayList<>();
		Connection myConn = null;
		Statement myStmt = null;
		ResultSet myRs = null;

		try {

			myConn = dataSource.getConnection();

			// Step 3: Create a SQL statement with JOIN to get role information
			String sql = "SELECT u.email, u.first_name, u.last_name, u.password, r.role_id, r.role_name "
					+ "FROM user u " + "JOIN role r ON u.role = r.role_id";

			myStmt = myConn.createStatement();

			// Step 4: Execute SQL query
			myRs = myStmt.executeQuery(sql);

			// Step 5: Process the result set
			while (myRs.next()) {
				String email = myRs.getString("email");
				String firstName = myRs.getString("first_name");
				String lastName = myRs.getString("last_name");
				String password = myRs.getString("password");
				int roleId = myRs.getInt("role_id");
				String roleName = myRs.getString("role_name");

				// Create new Role and User objects using extracted information
				Role role = new Role(roleId, roleName);
				User newUser = new User(email, firstName, lastName, password, role);

				// Add the new User object to the list
				user.add(newUser);
			}

			return user;

		} finally {
			// Close resources in a finally block
			close(myConn, myStmt, myRs);
		}
	}

	private void close(Connection myConn, Statement myStmt, ResultSet myRs) {

		try {
			if (myRs != null) {
				myRs.close();
			}

			if (myStmt != null) {
				myStmt.close();
			}

			if (myConn != null) {
				myConn.close();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public void addUser(User newUser) throws SQLException {
		Connection myConn = null;
		PreparedStatement myStmt = null;
		ResultSet myRs = null;

		try {
			// get DB connection
			myConn = dataSource.getConnection();

			// create SQL insert
			String sql = "INSERT INTO user (email, first_name, last_name, password, role) VALUES (?, ?, ?, ?, ?)";

			myStmt = myConn.prepareStatement(sql);

			// check if role ID exists in the role table
			String checkRoleSql = "SELECT * FROM role WHERE role_id = ?";
			PreparedStatement checkRoleStmt = myConn.prepareStatement(checkRoleSql);
			checkRoleStmt.setLong(1, newUser.getRole().getRoleId());
			myRs = checkRoleStmt.executeQuery();

			if (!myRs.next()) {
				throw new SQLException("Invalid role ID: " + newUser.getRole().getRoleId());
			}

			// set param value for the user
			myStmt.setString(1, newUser.getEmail());
			myStmt.setString(2, newUser.getFirstName());
			myStmt.setString(3, newUser.getLastName());
			myStmt.setString(4, newUser.getPassword());
			myStmt.setLong(5, newUser.getRole().getRoleId());

			// Execute SQL insert
			myStmt.execute();
		} finally {
			// clean up JDBC object
			close(myConn, myStmt, myRs);
		}
	}

	public User getUser(String email) throws Exception {

		User user = null;
		Connection myConn = null;
		PreparedStatement myStmt = null;
		ResultSet myRs = null;

		try {

			// get connection to database
			myConn = dataSource.getConnection();

			// create SQL to get selected user
			String sql = "SELECT * FROM user WHERE email = ?";

			// create prepared statement
			myStmt = myConn.prepareStatement(sql);

			// set parameter
			myStmt.setString(1, email);

			// Execute query
			myRs = myStmt.executeQuery();

			// Retrieve data from result row
			if (myRs.next()) {

				String useremail = myRs.getString("email");
				String firstName = myRs.getString("first_name");
				String lastName = myRs.getString("last_name");
				String password = myRs.getString("password");
				// get the role id from user table
				int roleId = myRs.getInt("role");

				// Query the role table to get the roleName for the roleId
				String checkRoleSql = "SELECT * FROM role WHERE role_id = ?";
				PreparedStatement checkRoleStmt = myConn.prepareStatement(checkRoleSql);
				checkRoleStmt.setInt(1, roleId);
				ResultSet roleRs = checkRoleStmt.executeQuery();
				if (roleRs.next()) {
					String roleName = roleRs.getString("role_name");
					// create a new Role object with the roleId and roleName
					Role role = new Role();
					role.setRoleId(roleId);
					role.setRoleName(roleName);
					// create a new User object with the retrieved data and Role object
					user = new User(useremail, firstName, lastName, password, role);
				} else {
					throw new Exception("Could not retrieve role for user with email " + email);
				}
			} else {
				throw new Exception("Could not find the user with email " + email);
			}
			return user;
		} finally {

			// clean up the JDBC objects
			close(myConn, myStmt, myRs);
		}
	}

	public void uppdateUser(User updatedUser) throws Exception {

		Connection myConn = null;
		PreparedStatement myStmt = null;
		ResultSet myRs = null;

		try {
			// create database connection
			myConn = dataSource.getConnection();

			// create SQL statement
			String sql = "UPDATE user " + "SET first_name=?, last_name=?, password=?, role=? " + "WHERE email = ?";

			// prepare statement
			myStmt = myConn.prepareStatement(sql);

			// check if role ID exists in the role table
			String checkRoleSql = "SELECT * FROM role WHERE role_id = ?";
			PreparedStatement checkRoleStmt = myConn.prepareStatement(checkRoleSql);
			checkRoleStmt.setLong(1, updatedUser.getRole().getRoleId());
			myRs = checkRoleStmt.executeQuery();

			if (!myRs.next()) {
				throw new SQLException("Invalid role ID: " + updatedUser.getRole().getRoleId());
			}

			// set param value for the user
			myStmt.setString(1, updatedUser.getFirstName());
			myStmt.setString(2, updatedUser.getLastName());
			myStmt.setString(3, updatedUser.getPassword());
			myStmt.setLong(4, updatedUser.getRole().getRoleId());
			myStmt.setString(5, updatedUser.getEmail());

			// Execute SQL update
			int rowsAffected = myStmt.executeUpdate();

			if (rowsAffected != 1) {
				throw new SQLException("Error updating user: " + updatedUser.getEmail());
			}

		} finally {
			// clean up the JDBC objects
			close(myConn, myStmt, null);
		}

	}

	public void deleteUser(String email) throws Exception {

		Connection myConn = null;
		PreparedStatement myStmt = null;

		try {
			// get a connection to database
			myConn = dataSource.getConnection();

			// create the SQL to delete the student
			String sql = "DELETE FROM USER WHERE email = ? ";

			// prepare the statement
			myStmt = myConn.prepareStatement(sql);

			// set up the params
			myStmt.setString(1, email);

			// execute SQL statement
			myStmt.execute();

		} finally {
			// clean up JDBC code
			close(myConn, myStmt, null);
		}

	}
}
