package dataaccess;

import java.sql.Connection;
import java.sql.SQLException;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

public class ConnectionPool {

	private static DataSource dataSource;	
	private static ConnectionPool instance = null;
	static {
		try {
			InitialContext ic = new InitialContext();
			dataSource = (DataSource) ic.lookup("java:/comp/env/jdbc/userdb");
		} catch (NamingException e) {
			throw new ExceptionInInitializerError("Failed to initialize DataSource");
		}
	}
	public static Connection getConnection() throws SQLException {
		return dataSource.getConnection();
	}
	private ConnectionPool() {
	}

	public static synchronized ConnectionPool getInstance() {
		if (instance == null) {
			instance = new ConnectionPool();
		}
		return instance;
	}
}
