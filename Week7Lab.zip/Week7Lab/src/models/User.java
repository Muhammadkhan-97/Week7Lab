package models;

import java.io.Serializable;

public class User implements Serializable {

	private String email;
	private String firstName;
	private String lastName;
	private String password;
	private Role role;

	public User(String email, String firstName, String lastName, String password, Role role) {
		this.email = email;
		this.firstName = firstName;
		this.lastName = lastName;
		this.password = password;
		this.role = role;
	}

	public String getEmail() {
		return email;
	}

	public String getFirstName() {
		return firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public String getPassword() {
		return password;
	}

	public Role getRole() {
		return role;
	}

	@Override
	public String toString() {
		return "User [email=" + email + ", firstName=" + firstName + ", lastName=" + lastName + ", password=" + password
				+ ", role=" + role + "]";
	}

}
